import { useState } from "react";
import Layout from "../components/Layout";

function Contact() {
  const [contact] = useState([
    { key: "6282237175125", value: "+62 822-3717-5125 (Solo)" },
    { key: "6282241128600", value: "+62 822-4112-8600 (Surabaya)" },
    { key: "6288228920906", value: "+62 882-2892-0906 (Klaten)" },
    { key: "6281228625917", value: "+62 812-2862-5917 (Yogyakarta)" },
    { key: "628999875143", value: "+62 899-9875-143 (Bandung)" },
  ]);

  const [address] = useState(
    `Jalan Jendral Ahmad Yani No.878, Cicaheum, Kiaracondong, Kota Bandung, Jawa Barat`
  );

  return (
    <Layout title={`Hubungi Kami`} style={`mt-20`}>
      <section
        className={`min-w-full flex-col flex justify-start space-y-2 items-start px-4 py-4 md:px-24`}
      >
        <div
          className={`min-w-full flex-col flex justify-start space-y-4 items-start px-4 py-10 md:px-24`}
        >
          <h1
            className={`font-bold text-xl md:text-2xl p-4 bg-gray-300 min-w-full rounded-md shadow-sm`}
          >
            Kontak Kami
          </h1>
          <div
            className={`text-base bg-gray-300 rounded-md shadow-sm p-4 min-w-full`}
          >
            <div className={`my-4`}>
              <h4 className="font-bold text-lg md:text-lg">Alamat Surel</h4>
              <ul>
                <li>dinatrium.creative@gmail.com</li>
              </ul>
            </div>
            <div className={`my-4`}>
              <h4 className="font-bold text-lg md:text-lg">Nomor Handphone</h4>
              <ul>
                {contact.map((el, i) => {
                  return (
                    <li key={i}>
                      <a href={`https://wa.me/${el.key}`}>{el.value}</a>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
        <div
          className={`min-w-full flex-col  flex justify-start space-y-4 items-start px-4 py-10 md:px-24`}
        >
          <h1
            className={`font-bold text-xl md:text-2xl p-4 bg-gray-300 min-w-full rounded-md shadow-sm`}
          >
            Alamat Kami
          </h1>
          <div
            className={`text-base bg-gray-300 rounded-md shadow-sm p-4 min-w-full`}
          >
            <p>{address}</p>
          </div>
        </div>
      </section>
    </Layout>
  );
}

export default Contact;
