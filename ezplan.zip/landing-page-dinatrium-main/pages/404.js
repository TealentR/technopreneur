import Link from "next/link";
import Layout from "../components/Layout";

export default function Home() {
  return (
    <Layout style="mt-24">
      <section
        className={`min-w-full min-h-screen flex justify-center items-center flex-col space-y-4`}
      >
        <h1 className={`text-xl md:text-2xl`}>:( Halaman tidak ditemukan</h1>
        <Link href={"/"}>
          <a
            className={`px-4 py-2 rounded-md shadow-sm bg-gray-400 hover:bg-gray-300`}
          >
            Kembali
          </a>
        </Link>
      </section>
    </Layout>
  );
}
