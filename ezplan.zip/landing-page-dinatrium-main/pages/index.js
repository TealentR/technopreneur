import Carousel from "../components/Carousel";
import Keunggulan from "../components/Keunggulan";
import Layout from "../components/Layout";
import Partner from "../components/Partner";
import TentangKami from "../components/TentangKami";

export default function Home() {
  return (
    <Layout style="mt-20">
      <Carousel></Carousel>
      <TentangKami></TentangKami>
      <Keunggulan></Keunggulan>
      <Partner></Partner>
    </Layout>
  );
}
