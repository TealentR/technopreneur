import { useState } from "react";
import Layout from "../components/Layout";

function AboutCompany() {
  const [info] = useState([
    { key: "Nama Perusahaan", value: "Dinatrium Nawacita Abadi" },
    { key: "CEO", value: "Rama Hadiwijaya Syahid Abdurrahman" },
    { key: "Commissioner", value: "Adzany Tealent Risabury" },
    {
      key: "Alamat",
      value:
        "Jalan Jendral Ahmad Yani No.878, Cicaheum, Kiaracondong, Kota Bandung, Jawa Barat",
    },
  ]);
  return (
    <Layout title={`Tentang Perusahaan`} style={`mt-20`}>
      <section
        className={`min-w-full flex-col min-h-screen flex justify-start space-y-4 items-start px-4 py-10 md:px-24`}
      >
        <h1
          className={`font-bold text-xl md:text-2xl p-4 bg-gray-300 min-w-full rounded-md shadow-sm`}
        >
          Tentang Perusahaan
        </h1>
        <p className={`text-base bg-gray-300 rounded-md shadow-sm p-4`}>
          Dinatrium adalah sebuah usaha yang bekerja dalam basis Kreatifitas
          karena usaha yang didalamnya terbentuk atas dasar keunikan yang ada.
          Kami selalu berusaha memberi harga yang cocok dalam setiap produk kami
          dan memkasimalkan produk yang kami berikan. Dengan anggotanya anak
          muda, konveksi kami bukan hanya sekedar konveksi konvensional. Kami
          berusaha mengikuti alur perkembangan zaman dan memanfaatkan teknologi
          dan tren yang ada.
        </p>
        <div className="bg-gray-300 rounded-md shadow-sm">
          {info.map((el, i) => {
            return (
              <div key={i} className={`grid grid-cols-2 gap-2 md:gap-5 p-4`}>
                <h2>{el.key}</h2>
                <p>: {el.value}</p>
              </div>
            );
          })}
        </div>
      </section>
    </Layout>
  );
}

export default AboutCompany;
