import { useState } from "react";
import Carousel from "../../components/Carousel";
import Layout from "../../components/Layout";

export const getServerSideProps = async ({ query: { slug } }) => {
  return { props: { slug } };
};

export default function Detail({ slug }) {
  const wa =
    "https://wa.me/6288228920906?text=Saya%20mau%20nyablon%20di%20Dinatrium%20min";

  const [sablon] = useState([
    "Rubber",
    "Plastisol",
    "DTF",
    "DTG",
    "Discharge",
    "Plascharge",
    "Printing (bukan sablon)",
  ]);
  const [bahan] = useState([
    {
      key: "PDL atau Korsa",
      isi: [
        "AMERICAN DRILL",
        "HISOFY",
        "JAPAN DRILL",
        "NAGATA DRILL",
        "RIPSTOK",
      ],
    },
    {
      key: "KEMEJA",
      isi: [
        "AMERICAN DRILL",
        "HISOFY",
        "JAPAN DRILL",
        "NAGATA DRILL",
        "RIPSTOK",
      ],
    },
    {
      key: "HOODIE",
      isi: ["BABYTERRY", "FLEECE"],
    },
    {
      key: "BOMBER",
      isi: ["BABYTERRY", "FLEECE"],
    },
    {
      key: "KAOS",
      isi: [
        "KATUN (Combed 20s, 24s, 30s)",
        "CARDET (20s, 30s",
        "KATUN BAMBOO (30s, 40s)",
        "TETERON COTTON",
        "POLYESTER Serta PE",
        "CVC (COTTON VISCOSE)",
      ],
    },
    {
      key: "TOTEBAG",
      isi: ["BLACU", "KANVAS"],
    },
    {
      key: "STRINGBAG",
      isi: ["BLACU", "KANVAS"],
    },
  ]);

  return (
    <Layout style="mt-20">
      <Carousel tipe={slug}></Carousel>
      <section
        className={`min-w-full py-12 bg-gray-200 flex justify-start items-center flex-col space-y-8`}
      >
        <h1 className={`text-xl md:text-2xl font-bold`}>{slug}</h1>
        <h2 className="px-8 text-center text-sm text-gray-500 md:text-base font-ligth italic">
          * bahan dan sablon bisa disesuaikan dengan kebutuhan anda
        </h2>
        <div className={`grid grid-cols-1 md:grid-cols-2 gap-5 md:min-w-full`}>
          <div
            className={`flex justify-start flex-col text-center items-center space-y-4`}
          >
            <h1 className={`text-lg md:text-xl font-semibold`}>Bahan</h1>
            <ul>
              {bahan
                ?.filter((el) => el.key === slug)[0]
                ?.isi.map((el, i) => {
                  return <li key={i}>{el}</li>;
                })}
            </ul>
          </div>
          <div
            className={`flex justify-start flex-col items-center text-center space-y-4`}
          >
            <h1 className={`text-lg md:text-xl font-semibold`}>Sablon</h1>
            <ul>
              {sablon.map((el, i) => {
                return <li key={i}>{el}</li>;
              })}
            </ul>
          </div>
        </div>

        <a
          className={`transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 hover:shadow-xl text-xl text-gray-50 hover:bg-gray-400 hover:text-gray-600 md:text-2xl font-bold px-4 py-2 rounded-md shadow-sm bg-gray-600`}
          href={wa}
          target={`_blank`}
        >
          Pesan Sekarang
        </a>
      </section>
    </Layout>
  );
}
