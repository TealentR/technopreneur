import Logo from "./Logo";
import { AiOutlineInstagram } from "react-icons/ai";

function Footer() {
  return (
    <section
      id={`footer`}
      className={`min-w-full bg-gray-400 py-6 px-2 md:px-24`}
    >
      <div className="flex md:flex-row md:justify-between flex-col justify-center items-center space-y-4 mb-8">
        <div className={`p-2 rounded-md min-w-full md:min-w-0`}>
          <Logo></Logo>
        </div>
        <div className="flex justify-start items-center space-x-4 p-2">
          <a
            href={`http://instagram.com/syaffapparel`}
            target="_blank"
            rel="noreferrer"
            className={`flex justify-center items-center space-x-2`}
          >
            <AiOutlineInstagram size={30}></AiOutlineInstagram>
            <p className={`hover:text-gray-600`}>syaffapparel</p>
          </a>
          <a
            href={`http://instagram.com/dinatrium.convection`}
            target="_blank"
            rel="noreferrer"
            className={`flex justify-center items-center space-x-2`}
          >
            <AiOutlineInstagram size={30}></AiOutlineInstagram>
            <p className={`hover:text-gray-600`}>dinatrium.convection</p>
          </a>
        </div>
      </div>
      <hr />
      <b className={`flex justify-center items-center mt-8 text-gray-800`}>
        &copy; {new Date().getFullYear()} Dinatrium Nawacita Abadi
      </b>
    </section>
  );
}

export default Footer;
