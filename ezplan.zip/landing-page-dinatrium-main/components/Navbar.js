import { useState } from "react";
import DesktopMenu from "./DesktopMenu";
import Logo from "./Logo";
import Icon from "./MobileMenu/Icon";
import Menu from "./MobileMenu/Menu";

function Navbar() {
  const [isMenu, setIsMenu] = useState(true);

  return (
    <nav
      className={`min-w-full bg-gray-400 px-4 md:px-24 py-2 fixed top-0 z-10 shadow-lg`}
    >
      <div className="flex justify-between items-center">
        <Logo></Logo>
        <Icon isMenu={isMenu} setIsMenu={setIsMenu}></Icon>
        <DesktopMenu></DesktopMenu>
      </div>
      {isMenu === false && <Menu></Menu>}
    </nav>
  );
}

export default Navbar;
