import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import SwiperCore, { Autoplay, Lazy, Pagination } from "swiper/core";

SwiperCore.use([Pagination, Lazy, Autoplay]);

function Carousel({ tipe = "" }) {
  const [images] = useState([
    { url: "/img/img.jpeg", name: "satu", slug: "PDL atau Korsa" },
    { url: "/img/img1.jpeg", name: "dua", slug: "HOODIE" },
    { url: "/img/img2.jpeg", name: "tiga", slug: "KEMEJA" },
    { url: "/img/img3.jpeg", name: "empat", slug: "KAOS" },
    { url: "/img/img4.jpeg", name: "lima", slug: "TOTEBAG" },
    { url: "/img/img6.jpeg", name: "tujuh", slug: "STRING BAG" },
    { url: "/img/img7.jpeg", name: "delapan", slug: "BOMBER" },
  ]);
  if (tipe === "") {
    return (
      <div className="pb-16 pt-4 flex justify-center items-center">
        <Swiper
          slidesPerView={1}
          centeredSlides={true}
          autoplay={{
            delay: 2500,
            disableOnInteraction: false,
          }}
          spaceBetween={30}
          loop={true}
          pagination={{
            clickable: true,
          }}
          lazy={true}
        >
          {images.map((e, i) => {
            return (
              <SwiperSlide key={i}>
                <Link href={`/produk/${e.slug}`}>
                  <a className="flex flex-col justify-center items-center">
                    <p className="text-gray-400 italic mb-2">
                      Click on the product
                    </p>
                    <Image src={e.url} width={500} height={500} alt={e.name} />
                  </a>
                </Link>
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    );
  } else {
    const detail = images.filter((el) => el.slug === tipe);
    return (
      <div className="py-16 flex justify-center items-center">
        <Swiper
          slidesPerView={1}
          centeredSlides={true}
          autoplay={{
            delay: 2500,
            disableOnInteraction: false,
          }}
          spaceBetween={30}
          pagination={{
            clickable: true,
          }}
          lazy={true}
          loop={false}
        >
          {detail.map((e, i) => {
            return (
              <SwiperSlide key={i}>
                <div className="flex justify-center items-center">
                  <Image src={e.url} width={500} height={500} alt={e.name} />
                </div>
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    );
  }
}

export default Carousel;
