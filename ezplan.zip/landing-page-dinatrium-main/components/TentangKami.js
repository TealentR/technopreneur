import Logo from "./Logo";

function TentangKami() {
  return (
    <section id="tentang-kami">
      <div className="bg-gray-300 px-5 py-16 md:py-24 grid grid-cols-1 md:grid-cols-3 gap-x-2 gap-y-4">
        <div className="md:col-span-2 flex flex-col justify-center items-center text-center space-y-4 md:space-y-4">
          <h1 className={`text-xl md:text-2xl font-semibold`}>Tentang Kami</h1>
          <p className={`text-sm md:text-base md:px-16`}>
            Dinatrium merupakan sebuah (usaha/perusahaan layanan/jasa/konveksi)*
            yang menjadikan kreatifitas sebagai bahan bakar utama dalam bergerak
            secara masif untuk membantu Anda mendapatkan produk konveksi
            terbaik. Kualitas merupakan prioritas; kepuasan pelanggan merupakan
            tujuan. Kami siap memberikan pelayanan yang terbaik dan unik bagi
            Anda.
          </p>
        </div>
        <div className="flex justify-center items-center">
          <Logo url={"/tentang-perusahaan"}></Logo>
        </div>
      </div>
    </section>
  );
}

export default TentangKami;
