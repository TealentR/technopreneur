import Head from "next/head";
import Footer from "./Footer";
import Navbar from "./Navbar";

function Layout({
  title = "Dinatrium",
  description = "Dinatrium konveksi. Menyediakan berbagai macam jasa layanan konveksi",
  children,
  style = "",
}) {
  return (
    <>
      <Head>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" href="/img/logo.png" />
      </Head>
      <Navbar></Navbar>
      <main className={style}>{children}</main>
      <Footer></Footer>
    </>
  );
}

export default Layout;
