import { useState } from "react";

function Partner() {
  const [partner] = useState([
    {
      name: "SMANSA KLATEN",
      img: "/img/img.jpeg",
    },
  ]);

  return (
    // <section
    //   id="partner"
    //   className={`flex flex-col justify-center items-center space-y-8 md:space-y-4 px-8 py-16 md:py-24`}
    // >
    //   <h1 className={`text-xl md:text-2xl font-semibold`}>Partner Kami</h1>
    //   <div className="grid grid-cols-4 md:grid-cols-6 gap-10">
    //     {partner.map((el, i) => {
    //       return (
    //         <div key={i} className="partner">
    //           {el.name}
    //         </div>
    //       );
    //     })}
    //   </div>
    // </section>
    <section
      id="partner"
      className={`flex justify-center items-center px-8 py-16 md:py-24`}
    >
      <q className={`text-4xl text-center md:text-6xl italic font-semibold`}>
        Your Desire is Our Priority
      </q>
    </section>
  );
}

export default Partner;
