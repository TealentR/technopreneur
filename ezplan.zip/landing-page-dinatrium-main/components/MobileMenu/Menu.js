import Link from "next/link";
import { useRouter } from "next/router";

function Menu() {
  const router = useRouter();

  return (
    <div
      className={`md:hidden flex flex-col justify-center items-center text-center my-4 space-y-3`}
    >
      <Link href="/">
        <a
          className={
            router.pathname === "/"
              ? `transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 min-w-full text-gray-50 bg-gray-500 border rounded-lg py-2`
              : `transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 min-w-full hover:text-gray-50 hover:bg-gray-500 border rounded-lg py-2`
          }
        >
          Home
        </a>
      </Link>
      <Link href="/tentang-perusahaan">
        <a
          className={
            router.pathname === "/tentang-perusahaan"
              ? `transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 min-w-full text-gray-50 bg-gray-500 border rounded-lg py-2`
              : `transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 min-w-full hover:text-gray-50 hover:bg-gray-500 border rounded-lg py-2`
          }
        >
          Tentang Perusahaan
        </a>
      </Link>
      <Link href="/hubungi-kami">
        <a
          className={
            router.pathname === "/hubungi-kami"
              ? `transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 min-w-full text-gray-50 bg-gray-500 border rounded-lg py-2`
              : `transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 min-w-full hover:text-gray-50 hover:bg-gray-500 border rounded-lg py-2`
          }
        >
          Hubungi Kami
        </a>
      </Link>
    </div>
  );
}

export default Menu;
