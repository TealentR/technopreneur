import Link from "next/link";
import { useRouter } from "next/router";

function DesktopMenu() {
  const router = useRouter();
  return (
    <div className="hidden md:flex justify-between items-center space-x-2">
      <Link href="/">
        <a
          className={
            router.pathname === "/"
              ? "transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 bg-gray-500 text-gray-50 px-4 py-2 rounded-lg hover:shadow-lg"
              : "transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 hover:bg-gray-500 hover:text-gray-50 px-4 py-2 rounded-lg hover:shadow-lg"
          }
        >
          Beranda
        </a>
      </Link>
      <Link href="/tentang-perusahaan">
        <a
          className={
            router.pathname === "/tentang-perusahaan"
              ? "transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 bg-gray-500 text-gray-50 px-4 py-2 rounded-lg hover:shadow-lg"
              : "transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 hover:bg-gray-500 hover:text-gray-50 px-4 py-2 rounded-lg hover:shadow-lg"
          }
        >
          Tentang Perusahaan
        </a>
      </Link>
      <Link href="/hubungi-kami">
        <a
          className={
            router.pathname === "/hubungi-kami"
              ? "transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 bg-gray-500 text-gray-50 px-4 py-2 rounded-lg hover:shadow-lg"
              : "transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 hover:bg-gray-500 hover:text-gray-50 px-4 py-2 rounded-lg hover:shadow-lg"
          }
        >
          Hubungi Kami
        </a>
      </Link>
    </div>
  );
}

export default DesktopMenu;
