import { useState } from "react";

function Keunggulan() {
  const [text] = useState([
    {
      title: "Harga Murah",
      sub: "Harga murah ≠ barang murahan. Anda bisa mendiskusikan kebutuhan dan kesesuaian budget yang dimiliki kepada kami. Dinatrium tetap mengutamakan quality control pada setiap produk yang akan mendarat ke tangan Anda.",
      svg: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-20 w-20"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      ),
    },
    {
      title: "Konsultasi Gratis",
      sub: "Jangan ragu untuk menanyakan hal-hal detail kepada kami, misalnya apa warna yang cocok untuk seragam komunitas sepeda Anda? Feel free to konsultasi!",
      svg: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-20 w-20"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
          />
        </svg>
      ),
    },
    {
      title: "Mudah & Cepat",
      sub: "Langsung hubungi kami melalui nomor WhatsApp: (sebutkan langsung) untuk segera memberikan penawaran dan mencapai kesepakatan yang klop dan cepat. Kami hadir 24/7 untuk Anda.",
      svg: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-20 w-20"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M5 13l4 4L19 7"
          />
        </svg>
      ),
    },
    {
      title: "Profesional & Berkualitas",
      sub: "Tim Dinatrium terdiri dari orang-orang yang expert dan memiliki unique-sense di bidangnya masing-masing. Dengan begitu, produk anda terjamin kualitasnya di tangan kami.",
      svg: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-20 w-20"
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
        </svg>
      ),
    },
  ]);

  return (
    <section
      id="keunggulan"
      className={`select-none flex flex-col justify-center items-center md:space-y-4 px-5 py-8 md:py-24 md:px-16`}
    >
      <h1 className={`text-xl md:text-2xl font-semibold`}>Keunggulan Kami</h1>
      <div className={`mt px-5 py-5 grid grid-cols-1 md:grid-cols-2 gap-10`}>
        {text.map(({ title, sub, svg }, i) => {
          return (
            <div
              key={i}
              className="flex space-y-2 flex-col justify-start items-center bg-gray-300 shadow-md transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 rounded-xl p-4 md:p-12"
            >
              {svg}
              <h2 className={`text-lg md:text-xl font-bold`}>{title}</h2>
              <p className={`text-sm md:text-base md:px-16 text-center`}>
                {sub}
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export default Keunggulan;
