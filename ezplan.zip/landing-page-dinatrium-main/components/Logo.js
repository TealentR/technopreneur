import Image from "next/image";
import Link from "next/link";

function Logo({ url = "/" }) {
  return (
    <div className="font-extrabold text-2xl">
      <Link href={url}>
        <a
          className={`py-3 px-2 flex justify-center items-center space-x-2 md:space-x-6`}
        >
          <Image
            src={`/img/logo.png`}
            width={32 * 1.5}
            height={18 * 1.5}
            alt="Logo Dinatrium"
          />
          <p className={`hover:text-gray-600 hidden md:flex`}>DINATRIUM</p>
        </a>
      </Link>
    </div>
  );
}

export default Logo;
